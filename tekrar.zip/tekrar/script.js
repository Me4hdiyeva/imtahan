// let i = 0 
// function button(){
//   i++;
//  console.log(i);

// }
// if(true){
// 	let x = "salam";
// }
// alert('x');

// let x = 1
// 1 == "1";

// function myFunction() {

function randomNumber(){
  let input = document.getElementById("inp").value;
  let randomNum =  0;
  let array = [ "A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",1,2,3,4,5,6,7,8,9,0]
let answr= document.getElementById('answr');
let data = '';
  for(let i=0; i<input; i++){
    randomNum = Math.round(Math.random() * array.length);
    data += array[randomNum];
  }
  answr.innerHTML = data;

}
